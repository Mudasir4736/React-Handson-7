import React from 'react';
import {useSelector} from 'react-redux'
import {Link, useNavigate} from 'react-router-dom'
const Student = () => {
    const users = useSelector((state) => state.users)
    const Navi=useNavigate()
    // console.log(users)
    return (
        <div>
            <h1>Student Component</h1>
            <button onClick={()=>Navi('/addnewstudent')}>Add New</button>
            <table border='2px' width='80%'>
<thead>
    <td>Name</td>
    <td>Age</td>
    <td>Course</td>
    <td>Batch</td>
    <td>Change</td>
</thead>
         
            {
                users.map((row)=>{
                    return(
                        <tr key={row.id}>
                            <td>{row.name}</td>
                            <td>{row.age}</td>
                            <td>{row.course}</td>
                            <td>{row.batch}</td>
                            <td> <Link to='/editstudent' state={(users.id)}>Edit</Link> </td>
                        </tr>
                    )
                })
            }
               </table>
        </div>
    );
}

export default Student;
