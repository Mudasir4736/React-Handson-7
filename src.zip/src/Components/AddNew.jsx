import React from 'react';
import {useSelector} from 'react-redux'
import {  useNavigate } from 'react-router-dom';
const AddNew = () => {
    const navi=useNavigate()
    

    const users = useSelector((state) => state.users)
    console.log(users)

    const newObj=[{
        name:'',
        age:'',
        course:'',
        batch:''
    }]
    console.log(newObj);
const handleChange=(e)=>{
    console.log('clicked');
    newObj[e.target.name]=e.target.value
}
const handleSubmit=()=>{

    navi(-1)

}
    return (
        <div>
            <input type="text" name='name' placeholder='Enter Name' onChange={handleChange} />
            <input type="text" name='age' placeholder='Enter Age' onChange={handleChange} />
            <br />
            <input type="text" name='course' placeholder='Enter Course' onChange={handleChange} />
            <input type="text" name='batch' placeholder='Enter Batch' onChange={handleChange} />
            <br />
            <button onClick={handleSubmit}>Submit</button>
        </div>
    );
}

export default AddNew;
