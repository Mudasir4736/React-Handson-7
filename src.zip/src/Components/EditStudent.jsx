import React from 'react';
import {useSelector} from 'react-redux'
import { useLocation, useNavigate } from 'react-router-dom';
const EditStudent = () => {
    const data=useLocation()
    console.log(data)
    const users = useSelector((state) => state.users)
    const navi=useNavigate()
    // console.log(users)
    return (
        <div>
             <input type="text" placeholder='' />
            <input type="text" placeholder='' />
            <br />
            <input type="text" placeholder='' />
            <input type="text" placeholder='' />
            <br />
            <button onClick={()=>navi(-1)}>Update</button>
        </div>
    );
}

export default EditStudent;
