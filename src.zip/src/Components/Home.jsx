import React from 'react';

const Home = () => {
    return (
        <div>
            <h1> This is my Home Component</h1> 
        </div>
    );
}

export default Home;
